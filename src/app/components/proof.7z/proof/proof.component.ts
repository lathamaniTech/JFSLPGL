import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Network } from '@awesome-cordova-plugins/network/ngx';
import { AlertController, ModalController, NavController, NavParams } from '@ionic/angular';
import { ExistingPage } from 'src/app/pages/existing/existing.page';
import { FingerprintPage } from 'src/app/pages/fingerprint/fingerprint.page';
import { KarzaDetailsPage } from 'src/app/pages/karza-details/karza-details.page';
import { ModalPage } from 'src/app/pages/modal/modal.page';
import { PicproofPage } from 'src/app/pages/picproof/picproof.page';
import { DataPassingProviderService } from 'src/providers/data-passing-provider.service';
import { GlobalService } from 'src/providers/global.service';
import { RestService } from 'src/providers/rest.service';
import { SqliteService } from 'src/providers/sqlite.service';

@Component({
  selector: 'app-proof',
  templateUrl: './proof.component.html',
  styleUrls: ['./proof.component.scss'],
})
export class ProofComponent implements OnInit {

  proofName: any;
  proofUserData: any;
  mandCheck: any;
  appliType: string;
  mandDocs: any = [];
  mandDocsCount: any;
  today: any = new Date();
  maxdate: any;
  mindate: any;
  aadharNum: any;

  submitstatus: any;
  entityDatalen: any = 0;
  promoterDatalen: any = 0;
  entiexpiry: any;
  promoexpiry: any;
  promodoi: any;
  proofImglen: any = 0;
  proofImgs = [];
  eproofImglen: any = 0;
  eproofImgs = [];
  public promoDoc;
  public entiDoc;
  proofType: any;
  entidoi: any;
  docs_master: any;
  docName: any;
  bdocs_master: any;
  bdocName: any;
  DocumentCode: any;
  bDocumentCode: any;
  docslist_master: any;
  bdocslist_master: any;

  refId: any;
  id: any;
  pproofId: any;
  eproofId: any;

  proofData: FormGroup;
  busiProofData: FormGroup;

  getPromodata: any;
  getEntitydata: any;
  userType: any;

  //SaveTick
  PromoterTick: boolean = false;
  EntityTick: boolean = false;
  submitDisable: boolean = false;
  esubmitDisable: boolean = false;
  IDTypeDisable: boolean = false;
  eIDTypeDisable: boolean = false;
  idNumDisable: boolean = false;
  expdate: boolean = false;
  eexpdate: boolean = false;
  documentDetails: boolean = false;
  entidocumentDetails: boolean = false;
  //auth: boolean = true;
  master_busiProofs: any;
  master_idProofs: any;

  selectOptions = {
    cssClass: 'remove-ok'
  };
  @Output() saveStatus = new EventEmitter();
  save: any = [];
  formActivater = { disableForm: true };
  pagename = 'KYC Details';
  username: any;

  //aadharVaultCode
  vaultStatus: string = '';
  janaRefId: boolean = false;
  aadharBtn: string = "Vault";
  vaultDisable: boolean = false;
  textType: any = "text";
  aadhar: boolean = false;
  leadId: any;
  ExCusData: any[];
  naveParamsValue: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
    public modalCtrl: ModalController, public formBuilder: FormBuilder,
    // public sqliteSupportProvider: SqliteSupportProvider, 
    public sqliteProvider: SqliteService, public alertCtrl: AlertController,
    public globalData: DataPassingProviderService, public router: Router, private activateRoute: ActivatedRoute,
    // public viewCtrl: ViewController, public events: Events,
    public globFunc: GlobalService, public network: Network, public master: RestService) {
    this.activateRoute.queryParamMap.subscribe((data: any) => {
      this.naveParamsValue = data.params;
      this.childConstructor(this.naveParamsValue);
    })
  }

  private childConstructor(value) {
    this.userType = this.globalData.getborrowerType();
    this.refId = this.globalData.getrefId();
    this.id = this.globalData.getId();

    // this.events.subscribe('product', (product) => {
      this.globalData.eventValue.subscribe(data => {
        this.getDocumentValue(data);
      })
    // });

    console.log(localStorage.getItem('product'))

    if (this.userType == "G" || this.userType == "C") {
      this.getDocumentValue();
    }
    this.getCibilCheckedDetails();

    this.getIdProofLength();
    if (this.refId === "" || this.refId === undefined || this.refId === null) {
      this.refId = "";
      // alert("save proof data");
    }
    else {

    }
    this.proofType = "ProofPromoter";
    this.proofData = this.formBuilder.group({
      promoIDType: ['', Validators.compose([Validators.required])],
      promoDoc: [''],
      promoIDRef: ['', Validators.required],
      promoexpiry: ['']
    });

    if (this.naveParamsValue.fieldDisable) {
      this.submitDisable = true;
      this.esubmitDisable = true;
    }
    this.calldate();
    this.callmaxdate();

    this.leadId = this.naveParamsValue.leadId;
    this.getLeadId()
    this.updateExCusData();
    // this.proofData.valueChanges.subscribe(() => {
    //   // console.log(this.QDEIndividualDemoGraphic);
    //   if (this.proofData.pristine == false) {
    //     if (this.proofData.status === "INVALID") {
    //       this.formActivater.disableForm = true;
    //       this.globFunc.setapplicationDataChangeDetector('modified', this.pagename);
    //     } else {
    //       this.formActivater.disableForm = false;
    //       this.globFunc.setapplicationDataChangeDetector('modified', this.pagename);
    //     }
    //   }
    // })
  }

  getLeadId() {
    this.sqliteProvider.getSourcingDetails(this.refId, this.id).then(data => {
      console.log(data);
      if (data.length > 0) {
        this.leadId = data[0].leadId;
        this.sqliteProvider.getEKYCDetails(this.leadId).then(val => {
          if (val.length > 0) {

          }
        }).catch(err => { console.log(err); })
      }
    });
  }


  ngOnInit() {
    // let root = this.viewCtrl.instance.navCtrl._app._appRoot;
    document.addEventListener('click', function (event) {
      let btn = <HTMLLIElement>document.querySelector('.remove-ok .alert-button-group');
      let target = <HTMLElement>event.target;
      if (btn && target.className == 'alert-radio-label' || target.className == 'alert-radio-inner' || target.className == 'alert-radio-icon') {
        // let view = root._overlayPortal._views[0];
        // let inputs = view.instance.d.inputs;
        // for (let input of inputs) {
        //   if (input.checked) {
        //     view.instance.d.buttons[1].handler([input.value]);
        //     view.dismiss();
        //     break;
        //   }
        // }
      }
    });
  }

  proofpromotersave(value) {
    if (this.aadhar && this.vaultStatus == 'N') {
      this.globalData.showAlert("Alert!", "Please complete aadhar vault process!!!");
      // } else if (this.promoterDatalen == 1 && this.validated == false) {
    }
    else {
      //  else if (this.validated == false) {
      //   this.globalData.showAlert("Alert!", "Please complete 2nd KYC Validation");
      // } 
      this.globalData.globalLodingPresent("Please wait...");
      // let saveStatus = localStorage.getItem('Personal');

      // if (saveStatus == "personalSaved") {
      // if (localStorage.getItem('Present') == "presentAddSaved") {
      if (localStorage.getItem('Personal') == "personalSaved") {
        // if (this.proofImgs.length > 0) {
        this.refId = this.globalData.getrefId();
        this.id = this.globalData.getId();
        this.sqliteProvider.addPromotersProofDetails(this.refId, this.id, value, this.vaultStatus, this.proofName, this.pproofId).then(data => {
          if (this.pproofId === "" || this.pproofId === null || this.pproofId === undefined) {
            this.pproofId = data.insertId;
            // this.uploadimg();
            this.globalData.globalLodingDismiss();
            if (this.userType == "A") {
              this.globalData.showAlert("Alert!", "Applicant Proof Details Added Successfully");
              this.formActivater.disableForm = true;
              this.globFunc.setapplicationDataChangeDetector('saved', this.pagename);
            }
            else if (this.userType == "G") {
              this.globalData.showAlert("Alert!", "Guarantor Proof Details Added Successfully");
              this.formActivater.disableForm = true;
              this.globFunc.setapplicationDataChangeDetector('saved', this.pagename);
            }
            else if (this.userType == "C") {
              this.globalData.showAlert("Alert!", "Co-Applicant Proof Details Added Successfully");
              this.formActivater.disableForm = true;
              this.globFunc.setapplicationDataChangeDetector('saved', this.pagename);
            }
            else {
              console.log("No user type Recived")
            }
            this.getIdProofLength(true);
            this.IDTypeDisable = false;
            this.vaultStatus = '';
            this.janaRefId = false;
          }
          else {
            // this.updateimg(this.pproofId);
            this.globalData.globalLodingDismiss();
            if (this.userType == "A") {
              this.globalData.showAlert("Alert!", "Applicant Proof Details Updated Successfully");
              this.formActivater.disableForm = true;
              this.globFunc.setapplicationDataChangeDetector('saved', this.pagename);
            }
            else if (this.userType == "G") {
              this.globalData.showAlert("Alert!", "Guarantor Proof Details Updated Successfully");
              this.formActivater.disableForm = true;
              this.globFunc.setapplicationDataChangeDetector('saved', this.pagename);
            }
            else if (this.userType == "C") {
              this.globalData.showAlert("Alert!", "Co-Applicant Proof Details Updated Successfully");
              this.formActivater.disableForm = true;
              this.globFunc.setapplicationDataChangeDetector('saved', this.pagename);
            }
            else {
              console.log("No user type Recived")
            }
            this.kycNo = 0;
            this.IDTypeDisable = false;
            this.vaultStatus = '';
            this.janaRefId = false;
          }
          this.clearpromo();
        }).catch(Error => {
          console.log("Failed!");
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "Failed!");
        })
        // }
        // else {
        //   this.globalData.globalLodingDismiss();
        //   this.globalData.showAlert("Alert!", "Please Add Proof Images.");
        // }
      } else {
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", "Must Save Personal Details");
      }
    }
  }

  async viewIdProof(value?) {
    const modal = await this.modalCtrl.create(
      {
        component: ModalPage,
        componentProps: { ID_proof: this.proofType, userType: this.userType, submitstatus: this.submitDisable }
      });
    modal.present();
    modal.onDidDismiss().then(async (value: any) => {
      let data = value.data
      if (value == "proofDelete") {
        this.clearpromo();
        this.getIdProofLength();
        this.proofImgs = [];
        this.proofImglen = 0;
        this.IDTypeDisable = false;
      }
      else if (value == "promoterDelete") {
        this.eproofImgs = [];
        this.eproofImglen = 0;
        this.eIDTypeDisable = false;
      }
      else if (data) {
        switch (this.proofType) {
          case 'ProofPromoter':
            this.clearpromo();
            if (data.promoexpiry == null || data.promoexpiry == "null") {
              data.promoexpiry = "";
            }

            this.proofData.get("promoIDType").setValue(data.promoIDType);
            this.promoDoc = data.promoDoc;
            this.proofData.get("promoIDRef").setValue(this.globFunc.basicDec(data.promoIDRef));
            this.proofData.get("promoexpiry").setValue(data.promoexpiry);
            this.IDTypeDisable = true;
            this.idNumDisable = true;
            this.pproofId = data.pproofId;
            this.vaultStatus = data.vaultStatus;

            this.proofName = data.proofName;
            if (data.proofName == 'DRIVING LICENSE' || data.proofName == 'PASSPORT') {
              this.expdate = true;
              // this.IDTypeDisable = true;
            } else {
              this.expdate = false;
              // this.IDTypeDisable = false;
            }
            // if (data.index == 1) {
            //   this.kycNo = 1
            //   this.validated = true;
            // } else {
            //   this.kycNo = 0
            //   //  this.validated=true;
            // }
            let valid = await this.firstKycCheck(data.promoIDType);
            if (valid) {
              this.kycNo = 1;
              this.validated = true;
            }


            console.log(this.kycNo, this.submitDisable);

            this.sqliteProvider.getpromoterproofImages(this.pproofId).then(data => {
              this.proofImgs = [];
              this.proofImgs = data;
              this.proofImglen = data.length;
              this.getIdProofLength();
            }).catch(Error => {
              console.log(Error);
            });
            break;
        }
      } else {
        //this.getPromoterProofDetails();
        switch (this.proofType) {
          case 'ProofPromoter':
            this.getIdProofLength();
            break;
          case 'ProofEntity':
            break;
        }
      }
    })
  }

  clearpromo() {
    this.pproofId = '';
    this.proofData = this.formBuilder.group({
      promoIDType: "",
      promoDoc: "",
      promoIDRef: "",
      promoexpiry: ""
    });
    this.promoDoc = "";
    //this.promoexpiry = "";
    this.proofData = this.formBuilder.group({
      promoIDType: ['', Validators.compose([Validators.required])],
      promoDoc: [''],
      promoIDRef: ['', Validators.compose([Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      promoexpiry: ['']
    });
  }

  getDocumentValue(value?) {
    let prdCode = localStorage.getItem('product') ? localStorage.getItem('product') : value ;
    let custType = this.globalData.getCustomerType();
    let entityStat;
    if (custType == '1') {
      entityStat = 'N';
      this.sqliteProvider.getDocumentsByIndividualPrdCode(prdCode, entityStat).then(data => {
        console.log(data, 'get docs');
        this.docs_master = data;
      });
    } else {
      entityStat = 'Y';
      this.sqliteProvider.getDocumentsByPrdCode(prdCode).then(data => {
        console.log(data, 'get docs else');
        this.docs_master = data;
      });
    }
  }

  docNames = {
    "DRIVING LICENSE": "licence",
    "PASSPORT": "passport",
    "VOTER ID": "voterid",
    "PAN CARD": "pan"
  }
  ExistdocNames = {
    "DRIVING LICENSE": "Driving Licence",
    "PASSPORT": "Passport",
    "VOTER ID": "Voter Identity Card",
    "PAN CARD": "PAN"
  }
  async firstKycCheck(docCode) {
    let docName = this.getDocumentName(docCode);
    if (docName == 'AADHAR CARD') {
      let value = await this.sqliteProvider.getEKYCDetails(this.leadId);
      console.log(value);
      return value.length > 0
    } else {
      let ExistCustType = this.globalData.getCustType();
      if (ExistCustType == 'E') {
        let ExistURN = this.globalData.getURN()
        let value = await this.sqliteProvider.getGivenExistingCustomerData(ExistURN);
        console.log(value);
        if (value.length > 0) {
          return (value.find(val => val.IdProof == this.ExistdocNames[docName]))
        }
      } else {
        let value = await this.sqliteProvider.getGivenKarzaDetailsByLeadid(this.leadId);
        console.log(value);
        if (value.length) {
          return (value.find(val => val.idType == this.docNames[docName]))
          //licence
          //passport
          //voterid
          //pan
        }
      }
    }
  }

  async getDocuments(value) {
    let docCode = value.detail.value
    this.refId = this.globalData.getrefId();
    this.id = this.globalData.getId();
    let valid = await this.firstKycCheck(docCode);
    console.log(valid);



    // if (this.kycNo == 1 && valid) {
    //   setTimeout(() => {
    //     this.globalData.showAlert("Alert!", "This Kyc Document's Already Validated");
    //   }, 400);
    // } else {
    this.sqliteProvider.checkProofDetails(docCode, this.id).then(data => {
      if (data.length > 0) {
        this.proofData.get("promoIDType").setValue("");
        this.proofData.get("promoIDRef").setValue("");
        this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
        setTimeout(() => {
          this.globalData.showAlert("Alert!", "This Kyc Document Already Exists!");
        }, 400);
      } else {
        if (valid) {
          this.kycNo = 0;
          this.validated = true;
        } else if (this.promoterDatalen >= 2) {
          this.kycNo = 0;
          this.validated = true;
        }
        else {
          this.kycNo = 1;
          this.validated = false;
        }
        if (this.getDocumentName(docCode) == 'DRIVING LICENSE') { // DL
          this.sqliteProvider.getKarzaData(this.leadId, 'licence').then(data => {
            if (data.length > 0) {
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue(this.globFunc.basicDec(data[0].idNumber));
              this.proofData.controls.promoexpiry.setValue(data[0].idExpiry.substring(6, 10) + "-" + data[0].idExpiry.substring(3, 5) + "-" + data[0].idExpiry.substring(0, 2));
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(17), Validators.minLength(15), Validators.required]));
              this.proofData.controls.promoexpiry.setValidators(Validators.compose([Validators.required]));
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
              this.idNumDisable = true;
              this.expdate = true;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
            } else {
              this.expdate = true;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
              this.idNumDisable = false;
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue('');
              this.proofData.controls.promoexpiry.setValue('');
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(17), Validators.minLength(15), Validators.required]));
              this.proofData.controls.promoexpiry.setValidators(Validators.compose([Validators.required]));
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
            }
          })
        } else if (this.getDocumentName(docCode) == 'PASSPORT') { // Pasport
          this.sqliteProvider.getKarzaData(this.leadId, 'passport').then(data => {
            if (data.length > 0) {
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue(this.globFunc.basicDec(data[0].idNumber));
              this.proofData.controls.promoexpiry.setValue(data[0].idExpiry.substring(6, 10) + "-" + data[0].idExpiry.substring(3, 5) + "-" + data[0].idExpiry.substring(0, 2));
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.pattern(/^[A-Za-z]{1}[0-9]{7}$/), Validators.maxLength(8), Validators.minLength(8), Validators.required]));
              this.proofData.controls.promoexpiry.setValidators(Validators.compose([Validators.required]));
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
              this.idNumDisable = true;
              this.expdate = true;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
            } else {
              this.idNumDisable = false;
              this.expdate = true;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue('');
              this.proofData.controls.promoexpiry.setValue('');
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.pattern(/^[A-Za-z]{1}[0-9]{7}$/), Validators.maxLength(8), Validators.minLength(8), Validators.required]));
              this.proofData.controls.promoexpiry.setValidators(Validators.compose([Validators.required]));
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
              //this.proofData.controls.promoIDRef.updateValueAndValidity();
            }
          })
        } else if (this.getDocumentName(docCode) == 'PAN CARD') { // PAN
          this.sqliteProvider.getPersonalDetailsByLeadId(this.leadId).then(data => {
            if (data.length > 0 && data[0].panNum != "" && data[0].panNum != undefined && data[0].panNum != null) {
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue(this.globFunc.basicDec(data[0].panNum));
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(10), Validators.minLength(10), Validators.pattern(/^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$/), Validators.required]));
              this.proofData.controls.promoexpiry.clearValidators();
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
              this.idNumDisable = true;
              this.expdate = false;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
            } else {
              this.idNumDisable = true;
              this.expdate = false;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
              setTimeout(() => {
                this.proofData.controls.promoIDType.setValue('');
                this.proofData.controls.promoIDType.updateValueAndValidity();
                if (this.userType == "A") {
                  this.globalData.showAlert("Alert!", "Kindly update the PAN availability in Applicant Details!");
                } else if (this.userType == "C") {
                  this.globalData.showAlert("Alert!", "Kindly update the PAN availability in Co-Applicant Details!");
                } else if (this.userType == "G") {
                  this.globalData.showAlert("Alert!", "Kindly update the PAN availability in Guarantor Details!");
                }
              }, 400);
              // this.proofName = this.getDocumentName(docCode);
              // this.proofData.controls.promoIDRef.setValue('');
              // this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(10), Validators.minLength(10), Validators.pattern(/^[a-zA-Z]{5}[0-9]{4}[a-zA-Z]{1}$/), Validators.required]));
              // this.proofData.controls.promoIDRef.updateValueAndValidity();

            }
          })
        } else if (this.getDocumentName(docCode) == 'AADHAR' || this.getDocumentName(docCode) == 'AADHAR CARD') {// aadhar
          if (this.userType == 'A') {
            this.sqliteProvider.getAadharNum(this.refId, this.id).then(data => {
              if (data.length > 0) {
                if (data[0].janaRefId != '' && data[0].janaRefId != undefined && data[0].janaRefId != null) {
                  this.idNumDisable = false;
                  this.expdate = false;
                  this.aadhar = true;
                  this.janaRefId = true;
                  this.proofName = this.getDocumentName(docCode);
                  this.proofData.controls.promoIDRef.setValue(data[0].janaRefId);
                  this.vaultStatus = data[0].vaultStatus;
                  // this.proofData.controls.promoIDRef.setValue('');
                  this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(12), Validators.minLength(12), Validators.pattern('[0-9]{12}'), Validators.required]));
                  this.proofData.controls.promoexpiry.clearValidators();
                  this.proofData.controls.promoIDRef.updateValueAndValidity();
                  this.proofData.controls.promoexpiry.updateValueAndValidity();
                } else {
                  this.idNumDisable = false;
                  this.aadhar = true;
                  this.expdate = false;
                  this.janaRefId = false;
                  this.vaultDisable = false;
                  this.proofName = this.getDocumentName(docCode);
                  this.proofData.controls.promoIDRef.setValue('');
                  this.vaultStatus = 'N';
                  this.textType = 'password';
                  this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(12), Validators.minLength(12), Validators.pattern('[0-9]{12}'), Validators.required]));
                  this.proofData.controls.promoexpiry.clearValidators();
                  this.proofData.controls.promoIDRef.updateValueAndValidity();
                  this.proofData.controls.promoexpiry.updateValueAndValidity();
                }
              } else {
                this.idNumDisable = false;
                this.aadhar = true;
                this.expdate = false;
                this.proofName = this.getDocumentName(docCode);
                this.vaultStatus = 'N';
                this.proofData.controls.promoIDRef.setValue('');
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(12), Validators.minLength(12), Validators.pattern('[0-9]{12}'), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
              }
            })
          } else {

            this.sqliteProvider.getEKYCDetails(this.leadId).then(ekyc => {
              if (ekyc.length > 0) {
                this.idNumDisable = true;
                this.aadhar = true;
                this.expdate = false;
                this.janaRefId = true;
                this.proofName = this.getDocumentName(docCode);
                this.proofData.controls.promoIDRef.setValue(ekyc[0].janaid);
                this.vaultStatus = 'Y';
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(12), Validators.minLength(12), Validators.pattern('[0-9]{12}'), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
              } else {
                this.idNumDisable = false;
                this.aadhar = true;
                this.vaultStatus = 'N';
                this.expdate = false;
                this.proofName = this.getDocumentName(docCode);
                this.proofData.controls.promoIDRef.setValue('');
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(12), Validators.minLength(12), Validators.pattern('[0-9]{12}'), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
              }
            })
          }
        } else if (this.getDocumentName(docCode) == 'VOTER ID') {// voter
          this.sqliteProvider.getKarzaData(this.leadId, 'voterid').then(data => {
            if (data.length > 0) {
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue(this.globFunc.basicDec(data[0].idNumber));
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(16), Validators.minLength(10), Validators.required]));
              this.proofData.controls.promoexpiry.clearValidators();
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
              this.idNumDisable = true;
              this.expdate = false;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
            } else if (this.ExCusData[0].SidVal != undefined || null || "") {
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue(this.ExCusData[0].SidVal);
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(16), Validators.minLength(10), Validators.required]));
              this.proofData.controls.promoexpiry.clearValidators();
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
              this.idNumDisable = true;
              this.expdate = false;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
            }
            else {
              this.idNumDisable = false;
              this.expdate = false;
              this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
              this.proofName = this.getDocumentName(docCode);
              this.proofData.controls.promoIDRef.setValue('');
              this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(16), Validators.minLength(10), Validators.required]));
              this.proofData.controls.promoexpiry.clearValidators();
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoexpiry.updateValueAndValidity();
            }
          });
        } else if (this.getDocumentName(docCode) == 'GSTIN') {
          this.sqliteProvider.getEntityDetails(this.refId, this.id).then(data => {
            if (data.length > 0) {
              if (data[0].gst != "" && data[0].gst != undefined && data[0].gst != null) {
                this.proofName = this.getDocumentName(docCode);
                this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
                this.proofData.controls.promoIDRef.setValue(this.globFunc.basicDec(data[0].gst));
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(30), Validators.minLength(10), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
                this.idNumDisable = true;
                this.expdate = false;
              } else {
                this.idNumDisable = false;
                this.expdate = false;
                this.proofName = this.getDocumentName(docCode);
                this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
                this.proofData.controls.promoIDRef.setValue('');
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(30), Validators.minLength(10), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
              }
            }
          })
        } else if (this.getDocumentName(docCode) == 'CIN') {
          this.sqliteProvider.getEntityDetails(this.refId, this.id).then(data => {
            if (data.length > 0) {
              if (data[0].cin != "" && data[0].cin != undefined && data[0].cin != null) {
                this.proofName = this.getDocumentName(docCode);
                this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
                this.proofData.controls.promoIDRef.setValue(this.globFunc.basicDec(data[0].cin));
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(30), Validators.minLength(10), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
                this.idNumDisable = true;
                this.expdate = false;
              } else {
                this.idNumDisable = false;
                this.expdate = false;
                this.proofName = this.getDocumentName(docCode);
                this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
                this.proofData.controls.promoIDRef.setValue('');
                this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(30), Validators.minLength(10), Validators.required]));
                this.proofData.controls.promoexpiry.clearValidators();
                this.proofData.controls.promoIDRef.updateValueAndValidity();
                this.proofData.controls.promoexpiry.updateValueAndValidity();
              }
            }
          })
        } else {
          this.idNumDisable = false;
          this.expdate = false;
          this.proofName = this.getDocumentName(docCode);
          this.aadhar = false; this.textType = 'text'; this.vaultDisable = false; this.janaRefId = false; this.vaultStatus = '';
          this.proofData.controls.promoIDRef.setValue('');
          this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.maxLength(30), Validators.minLength(10), Validators.pattern('[a-zA-Z0-9]*'), Validators.required]));
          this.proofData.controls.promoexpiry.clearValidators();
          this.proofData.controls.promoIDRef.updateValueAndValidity();
          this.proofData.controls.promoexpiry.updateValueAndValidity();
        }

      }
    });

    // }

  }

  async showpicmaodal(value) {
    if (value == "idproof") {
      const modal = await this.modalCtrl.create(
        {
          component: PicproofPage,
          componentProps: { proofpics: this.proofImgs, submitstatus: this.submitDisable }
        });
      modal.onDidDismiss().then(async (data: any) => {
        this.proofImgs = [];
        this.proofImgs = data;
        this.proofImglen = data.length;
      })
      modal.present();
    }
  }

  uploadimg() {
    for (let i = 0; i < this.proofImgs.length; i++) {
      this.sqliteProvider.addpromoterproofImages(this.refId, this.id, this.proofImgs[i].imgpath, this.pproofId).then(data => {
        // console.log("promoter image insert" + data);
      }).catch(Error => {
        console.log("Failed!" + Error);
        this.globalData.showAlert("Alert!", "Failed!");
      })
      //alert(i);
    }
    this.proofImgs = [];
    this.proofImglen = 0;
  }

  updateimg(upid) {
    //alert(upid);
    this.sqliteProvider.removepromoterproofImages(upid).then(data => {
      // console.log("promoter image delete" + data);
      //alert(upid);
      for (let i = 0; i < this.proofImgs.length; i++) {
        this.sqliteProvider.addpromoterproofImages(this.refId, this.id, this.proofImgs[i].imgpath, upid).then(data => {
          // console.log("promoter image insert" + data);
        }).catch(Error => {
          console.log("Failed!" + Error);
          this.globalData.showAlert("Alert!", "Failed!");
        })
        //alert(i);
      }
      this.proofImgs = [];
      this.proofImglen = 0;
    }).catch(Error => {
      console.log("Failed!" + Error);
      this.globalData.showAlert("Alert!", "Failed!");
    })
  }

  getIdProofLength(value = false) {
    this.sqliteProvider.getPromoterProofDetails(this.refId, this.id).then(data => {
      this.proofUserData = data;
      this.promoterDatalen = data.length;
      // if (this.promoterDatalen == 1) {
      //   this.kycNo = 1;
      // } else {
      //   this.kycNo = 0
      // }
      if (value) {
        this.kycNo = 0
      }
      if (this.promoterDatalen > 0) {
        // this.mandDocsCheck(value);
        this.mandDocsCheckcount(this.promoterDatalen, value);
      }
      else {
        this.PromoterTick = false;
        this.saveStatus.emit('noIdProof');
      }
    }).catch(Error => {
      console.log(Error);
    });
  }

  aadharValidation() {
    if (this.proofData.controls.promoIDRef.value.length == 12) {
      let str = this.proofData.controls.promoIDRef.value;
      str = str.split("");
      if (str[0] == str[1] && str[0] == str[2] && str[0] == str[3] && str[0] == str[4] && str[0] == str[5] && str[0] == str[6] && str[0] == str[7] && str[0] == str[8] && str[0] == str[9] && str[0] == str[10] && str[0] == str[11]) {
        this.proofData.controls.promoIDRef.setValue('');
        this.globalData.showAlert("Alert!", "Given Aadhar number is not valid!");
      }
    }
  }

  toUpperCase(frmGrpName, ctrlName) {
    this[frmGrpName].controls[ctrlName].setValue(this[frmGrpName].controls[ctrlName].value.toUpperCase());
  }

  getCibilCheckedDetails() {
    this.refId = this.globalData.getrefId();
    this.id = this.globalData.getId();
    this.sqliteProvider.getSubmitDetails(this.refId, this.id).then(data => {
      if (data.length > 0) {
        this.submitstatus = data[0].submitStat;
        if (data[0].cibilCheckStat == '1') {
          this.submitDisable = true;
          this.esubmitDisable = true;
        } else {
          this.submitDisable = false;
          this.esubmitDisable = false;
        }
      }
    })
  }

  calldate() {
    let dd = this.today.getDate();
    let mm = this.today.getMonth() + 1; //January is 0!
    let yyyy = this.today.getFullYear();
    if (dd < 10) {
      dd = '0' + dd;
    }
    if (mm < 10) {
      mm = '0' + mm;
    }
    let mindate = yyyy + '-' + mm + '-' + dd;
    this.mindate = mindate
  }

  callmaxdate() {
    let dd = this.today.getDate();
    let mm = this.today.getMonth() + 1; //January is 0!
    let yyyy = this.today.getFullYear() + 20;
    if (dd < 10) {
      dd = '0' + dd;
    }
    if (mm < 10) {
      mm = '0' + mm;
    }
    let maxdate = yyyy + '-' + mm + '-' + dd;
    this.maxdate = maxdate
  }


  clearpromoall() {
    this.pproofId = '';
    this.proofData = this.formBuilder.group({
      promoIDType: "",
      promoDoc: "",
      promoIDRef: "",
      promoexpiry: ""
    });
    this.promoDoc = "";
    //this.promoexpiry = "";
    this.proofData = this.formBuilder.group({
      promoIDType: ['', Validators.compose([Validators.required])],
      promoDoc: [''],
      promoIDRef: ['', Validators.compose([Validators.pattern('[a-zA-Z0-9]*'), Validators.required])],
      promoexpiry: ['']
    });
    this.proofImgs = [];
    this.proofImglen = 0;
    this.IDTypeDisable = false;
    // this.AdPanDisable = false;
  }

  getDocumentName(value: string) {
    let selectedDocName = this.docs_master.find((f) => {
      return f.DocID === value;
    })
    return selectedDocName.DocDesc.toUpperCase();
  }

  mandDocsCheck(value) {
    this.mandCheck = "";
    let docs;
    let custType = this.globalData.getCustomerType();
    if (custType == 1) {
      docs = {
        "DocPrdCode": localStorage.getItem('product'),
        "EntityDocFlag": "N"
      }
    } else {
      docs = {
        "DocPrdCode": localStorage.getItem('product'),
        "EntityDocFlag": ""
      }
    }
    this.sqliteProvider.getMandDocumentsByPrdCode(docs).then(data => {
      this.mandDocs = data;
      this.mandDocsCount = data.length;
      for (let i = 0; i < this.mandDocs.length; i++) {
        this.sqliteProvider.getPromoterProofDetailsByProofID(this.refId, this.id, this.mandDocs[i].DocID).then(data => {
          if (data.length > 0) {
            this.mandCheck = this.mandCheck + "true ";
          } else {
            this.mandCheck = this.mandCheck + "false ";
          }
          if (i == this.mandDocs.length - 1) {
            if (this.mandCheck.includes('false')) {
              this.PromoterTick = false;
              this.saveStatus.emit('noIdProof');
            } else {
              this.PromoterTick = true;
              this.saveStatus.emit('idproofTick');
              localStorage.setItem('Proof', 'proofSaved');

              // this.events.publish('lead', "proof");
              // this.proceedToNextPage(value);

            }
          }
        });
      }
    })
  }

  mandDocsCheckcount(docLength, value) {
    let manDocumentCount = 0;
    let custType = this.globalData.getCustomerType();
    console.log("Custype", custType);
    this.sqliteProvider.getProductValuesCount(localStorage.getItem('product')).then(data => {
      if (data) {
        if (custType == "1") {
          if (this.userType == "A") {
            manDocumentCount = +data[0].prdAppDocCount;
          } else if (this.userType == "G") {
            manDocumentCount = +data[0].prdGuaDocCount;
          } else if (this.userType == "C") {
            manDocumentCount = +data[0].prdCoappDocCount;
          }
        } else {
          manDocumentCount = +data[0].prdEntityDocCount;
        }
        if (docLength >= manDocumentCount) {
          this.PromoterTick = true;
          this.saveStatus.emit('idproofTick');
          localStorage.setItem('Proof', 'proofSaved');
          // this.events.publish('lead', "proof");
          // this.proceedToNextPage(value);
        } else {
          this.PromoterTick = false;
          this.saveStatus.emit('noIdProof');
        }
      }
    });
  }

  proceedToNextPage(value) {
    if (value) {
      if (this.userType == 'C') {
        let leadStatus;
        this.username = this.globFunc.basicDec(localStorage.getItem('username'));
        if (this.network.type == 'none' || this.network.type == "unknown") {
          leadStatus = "offline";
        } else {
          leadStatus = "online";
        }
        // this.globalData.proccedOk('Alert','proceed to existing leads').then(data=>{
        this.router.navigate(['./existing'], { queryParams: { username: this.username, _leadStatus: leadStatus } })
        // })
      }
    }
  }

  validated = false;
  kycNo = 0;
  async secKycValidation() {
    if (this.proofData.controls.promoIDRef.value) {
      this.globalData.globalLodingPresent("Please Wait...");
      try {
        let personal = await this.sqliteProvider.getPersonalDetails(this.refId, this.id);
        let leadId = personal[0].coAppGuaId;
        let idType = this.getDocumentName(this.proofData.controls.promoIDType.value[0]);
        console.log(idType, this.proofData.controls.promoIDRef.value);
        // this.validated = true
        this.globalData.globalLodingDismiss();
        if (this.globalData.getCustomerType() == '1') {
          if (idType == 'PAN CARD') {
            //this.initPosidex('pan', this.proofData.controls.promoIDRef.value, leadId);
            this.panKarza(idType, this.proofData.controls.promoIDRef.value, leadId);
          } else if (idType == 'VOTER ID') {
            //this.initPosidex('voterid', this.proofData.controls.promoIDRef.value, leadId);
            this.voterKarza(idType, this.proofData.controls.promoIDRef.value, leadId);
          } else if (idType == 'Driving License'.toUpperCase()) {
            if (this.proofData.controls.promoexpiry.value) {
              // this.initPosidex('drivingLicence', this.proofData.controls.promoIDRef.value, leadId);
              this.initKarzaAPi('drivingLicence', this.proofData.controls.promoIDRef.value, leadId);
            } else {
              setTimeout(() => {
                this.globalData.showAlert("Alert!", "enter expiry date!");
              }, 400);
            }
          } else if (idType == 'PASSPORT') {
            // this.initPosidex('passport', this.proofData.controls.promoIDRef.value, leadId);
            this.initKarzaAPi('passport', this.proofData.controls.promoIDRef.value, leadId);
          } else if (idType == 'AADHAR CARD') {
            if (this.vaultStatus == 'Y') {
              this.aadhaarVaultRetrieve('', true, leadId);
              // this.initAadhar('aadhar', this.proofData.controls.promoIDRef.value, leadId);
            } else {
              setTimeout(() => {
                this.globalData.showAlert("Alert!", "Please complete aadhar vault process!!!");
              }, 400);
            }
          }
        } else {
          this.stitchApiCall(idType, this.proofData.controls.promoIDRef.value, leadId);
        }

      } catch (err) {
        console.log(err)
        this.globalData.showAlert('Alert', err)
      }
    } else {
      this.globalData.globalLodingDismiss();
      this.globalData.showAlert('Alert', 'The Values are Empty')
    }
  }

  secKycData() {
    let idType = this.proofData.controls.promoIDType.value;
    console.log(this.getDocumentName(idType[0]), this.proofData.controls.promoIDRef.value);
  }

  initPosidex(idType, idNumber, leadId) {
    this.globalData.globalLodingPresent("Fetching data...");
    let body = {
      "idType": idType,
      "idvalue": idNumber,
      "leadid": leadId,
      "urnNumber": "LOS" + leadId
    }
    this.master.restApiCallAngular('posidexType1', body).then((result) => {
      console.log(result, 'init posidex');
      if (result != undefined && result != null && result != '') {
        if ((<any>result).errorCode === '000') {
          let res = JSON.parse((<any>result).result);
          let resList = res.customerResponseList[0];
          if (resList.matchCount == "1") {
            this.globalData.globalLodingDismiss();
            let urn = {
              "cifId": resList.customerList[0].matchURN
            }
            //this.cifDataValid(urn);
          } else {
            this.globalData.globalLodingDismiss();
            // console.log("Karza");
            if (this.globalData.getCustomerType() == '1') {
              if (idType == "voterid") {
                this.voterKarza(idType, idNumber, leadId);
              } else if (idType == "pan") {
                this.panKarza(idType, idNumber, leadId);
              } else {
                this.initKarzaAPi(idType, idNumber, leadId);
              }
            } else {
              this.stitchApiCall(idType, idNumber, leadId);
            }
          }
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", (<any>result).errorDesc);
        }
      }
    }, err => {
      if (err.name == "TimeoutError") {
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", err.message);
      } else {
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", err.statusText);
      }
    }).catch(err => {
      this.globalData.globalLodingDismiss();
      this.globalData.showAlert("Alert!", "Something went wrong!!!");
    })
  }

  voterKarza(idType, idNumber, leadId) {
    this.globalData.globalLodingPresent("Fetching data...");
    if (this.network.type == 'none' || this.network.type == "unknown") {
      this.globalData.globalLodingDismiss();
      this.globalData.showAlert("Alert!", "Kindly check your internet connection!!!");
    } else {
      let body = {
        "epic_no": idNumber,
        "UniqueID": leadId
      };
      this.master.restApiCallAngular('VoterIdAuthentication', body, 'Y').then((result) => {
        if ((<any>result).success) {
          let resData = JSON.parse((<any>result).responseData.VoterId);
          console.log(resData);
          if (resData.status_code == 101) {
            let res = resData.result;
            let name = res.name.replace(/[&\/\\#,+()$~%.'"-:*?<>{}]/g, '').trim();
            let father = res.rln_name.replace(/[&\/\\#,+()$~%.'"-:*?<>{}]/g, '').trim();
            this.validated = true
            let body = {
              "name": name,
              "fathername": father,
              "dob": res.dob,
              "idNumber": idNumber,
              "type": "voterid"
            }
            this.globalData.setCustType('N');
            this.globalData.globalLodingDismiss();
            this.sqliteProvider.InsertKarzaData(leadId, res.name, father, res.dob, idNumber, "", "", "", "", "", "", 'voterid', "", "Y");
            // this.navCtrl.push(NewapplicationPage, { voter: body, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
            // this.initKarzaAPi(idType, idNumber, leadId, body);

          } else if (resData.status_code == 102) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Invalid ID number or combination of inputs");
          } else if (resData.status_code == 103) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "No records found for the given ID or combination of inputs");
          } else if (resData.status_code == 104) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Max retries exceeded");
          } else if (resData.status_code == 105) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Missing Consent");
          } else if (resData.status_code == 106) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Multiple Records Exist");
          } else if (resData.status_code == 107) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Not Supported");
          } else if (resData.status_code == 108) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Internal Resource Unavailable");
          } else if (resData.status_code == 109) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Too many records Found");
          } else if (resData.status_code == 222) {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", resData.error ? resData.error : "Response is Empty");
          }
          else {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", resData.error);
          }
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "Something went wrong!!!");
        }
      }, async error => {
        let alert = await this.alertCtrl.create({
          header: 'Alert!',
          message: 'KYC Verification is failed. Would you like to proceed with Offline Application Processing?',
          buttons: [
            {
              text: 'No',
              role: 'cancel',
              handler: () => {
                this.globalData.globalLodingDismiss();
                // this.navCtrl.push(JsfhomePage);
              }
            },
            {
              text: 'Yes',
              handler: () => {
                this.globalData.globalLodingDismiss();
                this.globalData.setCustType('N');
                // this.navCtrl.push(NewapplicationPage, { leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
              }
            }
          ]
        });
        await alert.present();
      }).catch(err => {
        console.log(err)
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", "No Response From Server!");
      })
    }
  }

  panKarza(idType, idNumber, leadId) {
    this.globalData.globalLodingPresent("Fetching data...");
    if (this.network.type == 'none' || this.network.type == "unknown") {
      this.globalData.globalLodingDismiss();
      this.globalData.showAlert("Alert!", "Kindly check your internet connection!!!");
    } else {
      let body = {
        "pan": idNumber,
        "uniqueID": leadId
      };
      this.master.restApiCallAngular('panvalidation', body, 'Y').then((result) => {
        if ((<any>result).success) {
          let resData = JSON.parse((<any>result).responseData.panValidation);
          resData = resData.NSDL.Response.details;
          console.log(resData);
          if (resData[0].StatusCode == "1" && resData[0].Panstatus == "E") {
            this.validated = true
            let res = resData[0];
            let name = res.nameOnCard.replace(/[&\/\\#,+()$~%.'"-:*?<>{}]/g, '').trim();
            let firstname = res.firstName.replace(/[&\/\\#,+()$~%.'"-:*?<>{}]/g, '').trim();
            let lastname = res.lastName.replace(/[&\/\\#,+()$~%.'"-:*?<>{}]/g, '').trim();
            let middlename = res.middleName.replace(/[&\/\\#,+()$~%.'"-:*?<>{}]/g, '').trim();
            let body = {
              "name": name,
              "firstname": firstname,
              "lastname": lastname,
              "middlename": middlename,
              "idNumber": idNumber,
              "type": "pan"
            }
            this.globalData.setCustType('N');
            this.globalData.globalLodingDismiss();
            this.sqliteProvider.InsertKarzaData(leadId, name, "", res.dob, idNumber, "", "", "", "", "", "", 'pan', "", "Y");
            // this.initKarzaAPi(idType, idNumber, leadId, body);
            // this.navCtrl.push(NewapplicationPage, { pan: body, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });

          } else {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", "Invalid PAN number");
          }
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", (<any>result).responseData.errorDesc);
        }
      }, async error => {
        let alert = await this.alertCtrl.create({
          header: 'Alert!',
          message: 'KYC Verification is failed. Would you like to proceed with Offline Application Processing?',
          buttons: [
            {
              text: 'No',
              role: 'cancel',
              handler: () => {
                this.globalData.globalLodingDismiss();
                // this.navCtrl.push(JsfhomePage);
              }
            },
            {
              text: 'Yes',
              handler: () => {
                this.globalData.globalLodingDismiss();
                this.globalData.setCustType('N');
                // this.navCtrl.push(NewapplicationPage, { leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
              }
            }
          ]
        });
        await alert.present();
      }).catch(err => {
        console.log(err)
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", "No Response From Server!");
      })
    }
  }

  stitchApiCall(idType, idNumber, leadId) {
    if (this.network.type == 'none' || this.network.type == "unknown") {
      this.globalData.globalLodingDismiss();
      this.globalData.showAlert("Alert!", "Kindly check your internet connection!!!");
    } else {
      let body = {
        "id": idNumber
      };
      this.master.restApiCallAngular('StitchApi', body).then((result: any) => {
        if (result.errorCode == '000') {
          let res = JSON.parse(result.Reposne);
          let gst;
          let gstNo;
          let obj;
          let cin = '';
          let tan = '';

          if (res.result) {
            if (!(Object.keys(res.result).length === 0)) {
              if (res.result.statutoryRegistration.gst) {
                gst = res.result.statutoryRegistration.gst;
                if (gst.length > 0) {
                  gstNo = gst[gst.length - 1].gstin;
                  obj = gst[gst.length - 1];
                } else {
                  gstNo = ""
                  obj = {
                    legalName: res.result.management.current[0].name,
                    pan: res.result.management.current[0].pans[0],
                    email: res.result.management.current[0].email,
                    pin: res.result.management.current[0].pin,
                    contact: ""
                  }
                }
              } else {
                gstNo = ""
                obj = {
                  legalName: res.result.management.current[0].name,
                  pan: res.result.management.current[0].pans[0],
                  email: res.result.management.current[0].email,
                  pin: res.result.management.current[0].pin,
                  contact: ""
                }
              }
              // event == 'gst' || event == 'tan' || event == 'cin'
              if (idType == 'gst') {
                gstNo = idNumber;
              } else if (idType == 'cin') {
                cin = idNumber;
              } else if (idType == 'tan') {
                tan = idNumber;
              }

              if (res.statusCode == 101) {
                let body = {
                  "leadId": leadId,
                  "entityName": res.result.profile.tradeName || res.result.profile[0].tradeName,
                  "entityId": res.result.profile.entityId,
                  "proName": obj.legalName,
                  "idType": idType,
                  "gst": gstNo,
                  "cin": cin,
                  "tan": tan,
                  "pan": obj.pan,
                  "proEmail": obj.email,
                  "proPin": obj.pin,
                  "contact": obj.contact
                }
                this.globalData.globalLodingDismiss();
                this.globalData.setCustType('N');
                this.sqliteProvider.InsertEntityKarzaData(body);
                // this.navCtrl.push(NewapplicationPage, { nonIndividual: body, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
              } else if (res.statusCode == 102) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Invalid ID number or combination of inputs");
              } else if (res.statusCode == 103) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "No records found for the given ID or combination of inputs");
              } else if (res.statusCode == 104) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Max retries exceeded");
              } else if (res.statusCode == 105) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Missing Consent");
              } else if (res.statusCode == 106) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Multiple Records Exist");
              } else if (res.statusCode == 107) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Not Supported");
              } else if (res.statusCode == 108) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Internal Resource Unavailable");
              } else if (res.statusCode == 109) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Too many records Found");
              } else {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", res.statusMessage);
              }
            } else {
              if (res.statusCode == 102) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Invalid ID number or combination of inputs");
              } else if (res.statusCode == 103) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "No records found for the given ID or combination of inputs");
              } else if (res.statusCode == 104) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Max retries exceeded");
              } else if (res.statusCode == 105) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Missing Consent");
              } else if (res.statusCode == 106) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Multiple Records Exist");
              } else if (res.statusCode == 107) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Not Supported");
              } else if (res.statusCode == 108) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Internal Resource Unavailable");
              } else if (res.statusCode == 109) {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", "Too many records Found");
              } else {
                this.globalData.globalLodingDismiss();
                this.globalData.showAlert("Alert!", res.statusMessage);
              }
            }
          } else {
            this.globalData.globalLodingDismiss();
            this.globalData.showAlert("Alert!", res.error);
          }
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", result.errorStatus);
        }
      }, async err => {
        let alert = await this.alertCtrl.create({
          header: 'Alert!',
          message: 'KYC Verification is failed. Would you like to proceed with Offline Application Processing?',
          buttons: [
            {
              text: 'No',
              role: 'cancel',
              handler: () => {
                this.globalData.globalLodingDismiss();
                // this.navCtrl.push(JsfhomePage);
              }
            },
            {
              text: 'Yes',
              handler: () => {
                this.globalData.globalLodingDismiss();
                this.globalData.setCustType('N');
                // this.navCtrl.push(NewapplicationPage, { leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
              }
            }
          ]
        });
        await alert.present();

        // this.globalData.globalLodingDismiss();
        // this.globalData.showAlert("Alert!", error.statusText);
      })
    }
  }

  async initKarzaAPi(idType, idNumber, leadId, body?,) {
    const modal = await this.modalCtrl.create(
      {
        component: KarzaDetailsPage,
        componentProps: { data: JSON.stringify(body), idType: idType, idNumber: idNumber, leadId: leadId, leadStatus: 'online', userType: this.globalData.getborrowerType(), secondKyc: 'Y' }
      });

    modal.onDidDismiss().then((data) => {
      console.log(data, "data");
      this.globalData.globalLodingDismiss();
      if (data) {
        if (idType == 'drivingLicence') {
          this.globalData.setCustType('N')
          this.globFunc.globalLodingDismiss();
          this.validated = true;
          this.globFunc.secKycAdd({ id: 'dl', val: data });
          // this.navCtrl.push(NewapplicationPage, { licence: data, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
        } else if (idType == 'passport') {
          this.globalData.setCustType('N')
          this.globFunc.globalLodingDismiss();
          this.validated = true;
          // this.navCtrl.push(NewapplicationPage, { passport: data, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
        }
      }
    })
    modal.present();
  }

  async initAadhar(idType, idNumber, leadId, body?,) {

    const modal = await this.modalCtrl.create(
      {
        component: FingerprintPage,
        componentProps: { idType: idType, idNumber: idNumber, leadId: leadId, leadStatus: 'online', janaId: this.janaId, second: true, ekyc: 'OTP' }
      })
    modal.onDidDismiss().then((data) => {
      console.log(data, "data");
      this.globalData.globalLodingDismiss();
      if (data) {
        if (idType == 'aadhar') {
          this.globalData.setCustType('N')
          this.globFunc.globalLodingDismiss();
          this.validated = true;
          this.globFunc.secKycAdd({ id: 'aadhar', val: data });
          // this.navCtrl.push(NewapplicationPage, { licence: data, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
        } else if (idType == 'passport') {
          this.globalData.setCustType('N')
          this.globFunc.globalLodingDismiss();
          this.validated = true;
          // this.navCtrl.push(NewapplicationPage, { passport: data, leadStatus: this.leadStatus, leadId: leadId, userType: this.globFunc.getborrowerType() });
        }
      }
    })
    modal.present();
  }

  janaId;
  aadhaarVaultInsert(value) {
    if (this.network.type === 'none' || this.network.type == 'unknown') {
      this.globalData.showAlert("Alert!", "Please Check your Data Connection!");
    } else {
      this.globalData.globalLodingPresent('Getting reference number!!!');
      let body = {
        "aadhaar": this.proofData.controls.promoIDRef.value
      }
      this.master.restApiCallAngular('AadharInsertVoulting', body).then((data) => {
        if ((<any>data).status == '00') {
          this.janaId = (<any>data).janaId
          this.sqliteProvider.getPromoterProofDetailsByProof(this.refId, (<any>data).janaId).then(pro => {
            if (pro.length > 0) {
              this.globalData.globalLodingDismiss();
              this.vaultStatus = 'N';
              this.janaRefId = false;
              this.proofData.controls.promoIDRef.setValue("");
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.aadharBtn = "Vault";
              this.vaultDisable = false;
              this.textType = 'password';
              this.globalData.showAlert("Alert!", "Given aadhar number already used in this application!");
            } else {
              this.globalData.globalLodingDismiss();
              this.vaultStatus = 'Y';
              this.janaRefId = true;
              this.proofData.controls.promoIDRef.setValue("");
              this.proofData.controls.promoIDRef.clearValidators();
              this.proofData.controls.promoIDRef.updateValueAndValidity();
              this.proofData.controls.promoIDRef.setValue((<any>data).janaId);
              this.aadharBtn = "Retrieve";
              this.vaultDisable = true;
              this.textType = 'text';
            }
          })
        } else {
          this.vaultDisable = false;
          this.janaRefId = false;
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", (<any>data).error);
        }
      }, (err) => {
        if (err.name == "TimeoutError") {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", err.message);
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "No Response from Server!");
        }
      });
    }
  }
  vaultNo = 0;
  aadhaarVaultRetrieve(value, second?, leadId?) {
    if (this.network.type === 'none' || this.network.type == 'unknown') {
      this.globalData.showAlert("Alert!", "Please Check your Data Connection!");
    } else {
      if (second) {
        console.log(second);
      } else {
        this.globalData.globalLodingPresent('Getting aadhar number!!!');
      }
      let body = {
        "keyValue": this.proofData.controls.promoIDRef.value
      }
      this.master.restApiCallAngular('aadharretrieveService', body).then((data) => {
        if ((<any>data).status == '00') {
          if (second) {
            this.vaultNo = (<any>data).aadhaar;
            this.initAadhar('aadhar', this.vaultNo, leadId);
          } else {
            this.globalData.globalLodingDismiss();
            this.vaultStatus = 'Y';
            this.vaultDisable = true;
            this.aadharBtn = "Retrieve";
            this.globalData.showAlert("Alert!", "Given aadhar number is " + (<any>data).aadhaar);

          }
        } else {
          this.vaultDisable = true;
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", (<any>data).error);
        }
      }, (err) => {
        if (err.name == "TimeoutError") {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", err.message);
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "No Response from Server!");
        }
      });
    }
  }

  removeVault() {
    this.refId = this.globalData.getrefId();
    this.id = this.globalData.getId();
    this.sqliteProvider.getAadharNum(this.refId, this.id).then(data => {
      if (data.length > 0) {
        if (data[0].janaRefId != '' && data[0].janaRefId != undefined && data[0].janaRefId != null) {
          this.globalData.showAlert("Alert!", "Cannot be remove here!");
        } else {
          this.vaultStatus = 'N';
          this.proofData.controls.promoIDRef.setValue("");
          this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.pattern('[0-9]*'), Validators.maxLength(12), Validators.minLength(12), Validators.required]));
          this.proofData.controls.promoIDRef.updateValueAndValidity();
          this.aadharBtn = "Vault";
          this.vaultDisable = false;
          this.janaRefId = false;
        }
      } else {
        this.vaultStatus = 'N';
        this.proofData.controls.promoIDRef.setValue("");
        this.proofData.controls.promoIDRef.setValidators(Validators.compose([Validators.pattern('[0-9]*'), Validators.maxLength(12), Validators.minLength(12), Validators.required]));
        this.proofData.controls.promoIDRef.updateValueAndValidity();
        this.aadharBtn = "Vault";
        this.vaultDisable = false;
        this.janaRefId = false;
      }
    });
  }

  viewAadhar() {
    if (this.textType == "password") {
      this.textType = "text";
    } else {
      this.textType = "password";
    }
  }

  cifDataValid(value) {
    // if (this.promoterURN == value.cifId || this.promoterURN_Coapp == value.cifId) {
    //   this.globalData.showAlert("Alert!", "Sorry! Applicant Cannot be a Guarantor");
    // } else {
    this.globalData.globalLodingPresent("Please wait...");
    let cifvalues = {
      "CustRequest":
      {
        "OrgSelect": "4525", // this.globalData.getJanaCenter(), //org scode
        "SearchText": "2520051515162097", //URN
        "CategryType": "HL" //Module
      }
    }
    this.master.restApiCallAngular('ExCustDetails', cifvalues).then((data) => {
      console.log(JSON.stringify(data));
      let exdata = (<any>data);
      if (exdata.ErrorCode == "000") {
        if (exdata.RedFlag == "true") {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "Given URN is Red Flag, should not be proceed further!!!");
        } else if (exdata.Urnno == value.cifId) {
          // this.globalData.setURN(value.cifId);
          // this.sqliteProvider.selectExData(this.globalData.getURN()).then(getData => {
          // this.globalData.setborrowerType('G');
          // this.globalData.setCustType('E');
          // this.globalData.setCustType('N')
          this.globalData.globalLodingDismiss();
          this.validated = true;
          // if (getData.length == 0) {
          this.sqliteProvider.saveExistingData(exdata).then(_ => {
            // this.aadharExistCheck(exdata, data);
            // this.navCtrl.pop();
            // this.navCtrl.push(CifDataPage, { cifData: data, GrefId: this.navParams.get('GrefId'), GId: this.navParams.get('GId'), leadId: this.leadId });
          }, err => console.log(err));
          // } else {
          // this.sqliteProvider.updateExistingData(data).then(_ => {
          // this.aadharExistCheck(exdata, data);
          // this.navCtrl.pop();
          // this.navCtrl.push(CifDataPage, { cifData: data, GrefId: this.navParams.get('GrefId'), GId: this.navParams.get('GId'), leadId: this.leadId });
          // }, err => console.log(err));
          // }
          // })
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "Enter Valid URN");
        }
      } else {
        if (exdata.AppId == '0') {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", "Not a valid URN!");
        } else {
          this.globalData.globalLodingDismiss();
          this.globalData.showAlert("Alert!", exdata.ErrorMsg);
        }
      }

    }, (err) => {
      if (err.name == "TimeoutError") {
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", err.message);
      } else {
        this.globalData.globalLodingDismiss();
        this.globalData.showAlert("Alert!", "No Response from Server!");
      }
    });

    // }
  }


  updateExCusData() {
    // let custType = this.globalData.getCustomerType();
    // if (custType == '1') {
    let urn = this.globalData.getURN()
    console.log('EXT URN is ', urn,);
    this.sqliteProvider.selectExData(urn).then(data => {
      this.ExCusData = data
    })
    // }
  }


}
